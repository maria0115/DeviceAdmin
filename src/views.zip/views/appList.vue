<template>
  <div class="dwp-app-list">
    <ul>
      <li>
        <a>
          <span>
            <img src="../library/images/menu_icon_user.svg" />
          </span>
          <em>사용정보</em>
        </a>
      </li>
      <li>
        <a>
          <span>
            <img src="../library/images/menu_icon_authority,.svg" />
          </span>
          <em>권한관리</em>
        </a>
      </li>
      <li>
        <a>
          <span>
            <img src="../library/images/menu_icon_stats.svg" />
          </span>
          <em>통계</em>
        </a>
      </li>
      <li>
        <a>
          <span>
            <img src="../library/images/menu_icon_server.svg" />
          </span>
          <em>서버설정</em>
        </a>
      </li>
      <li>
        <a>
          <span>
            <img src="../library/images/menu_icon_adminsetting.svg" />
          </span>
          <em>관리자설정</em>
        </a>
      </li>
    </ul>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>